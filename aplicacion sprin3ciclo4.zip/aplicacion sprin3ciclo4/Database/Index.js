const mongoose = require("mongoose");

const MONGO_URL =""

const db = async () =>{
    await mongoose
    .conect(MONGO_URL)
    .then(() => console.log("DB FUNCIONANDO"))
    .Cath((error) => console.error(error));
};

module.exports =db;
