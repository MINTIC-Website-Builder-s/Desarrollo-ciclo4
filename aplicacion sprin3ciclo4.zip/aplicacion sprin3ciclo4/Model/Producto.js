const { model, Schema } = require ("mongoose");

const cartSchema = new Schema({
    name: { type: String, require : true, unique: true}, 
    img:  { type: String, require : true}, 
    inCart : { type: Boolean, default : false}, 
    price : { type: Number, require : true}, 
});

model.export = model("Product", ProductSchema);