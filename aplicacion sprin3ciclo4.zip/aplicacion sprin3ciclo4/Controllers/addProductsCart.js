constCart=require(".. /modelo/carrito");
constProduct=require(".. /modelo/producto");

constaddProductCart=async(req,res) => {
  const{name,img,price}=req. cuerpo;

  /* verificamos si tenemos el producto */
  constestaEnProducts=awaitProduct. findOne({nombre});

  /* verificamos si todos los campos vienen con info */
  constnoEstaVacio=name!==""&&img!==""&&price!== "";

  /* verificamos si el producto ya esta en el carrito */
  constestaEnElCarrito=awaitCart. findOne({nombre});

  /* Si no tenemos el producto */
  si(! estaEnProductos) {
    res. estado(400). JSON({
      mensaje:"Este producto no se encuentra en nuestra base de datos",
    });

    /* Si nos envian algo y no esta en el carrito lo agregamos */
  } elseif(noEstaVacio&&! estaEnElCarrito) {
    constnewProductInCart=newCart({name,img,price,amount:1 });

    /* Y actualizamos la prop inCart: true en nuestros productos */
    esperarproducto. findByIdAndUpdate(
      estaEnProducts?. _id,
      { inCart:true,name,img,price},
      { nuevo:verdadero }
    )
      . then((producto) => {
        newProductInCart. salvar();
        res. JSON({
          mensaje:'El producto fue agregado al carrito',
producto,
        });
      })
      . catch((error)=>consola.  error(error));

    /* Y si esta en el carrito avisamos */
  } else if (estaEnElCarrito) {
    res. estado(400). JSON({
      mensaje:"El producto ya esta en el carrito",
    });
  }
};

módulo. exports=addProductCart;